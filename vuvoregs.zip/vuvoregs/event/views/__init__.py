# event/views/__init__.py
from .ajax import *  # noqa: F403
from .billing import *  # noqa: F403
from .events import *  # noqa: F403
from .payments import *  # noqa: F403
from .registration import *  # noqa: F403
from event.views import event_list, race_list
